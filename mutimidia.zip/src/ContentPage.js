import React from 'react';

const ContentPage = () => {
  return (
    <div>
      <h2>Bem-vindo à página de conteúdo privado!</h2>
      <p>Somente usuários registrados têm acesso a esta página.</p>
      <a href="http://localhost:3000/netfli">
      Netflix Filme  
<p>

</p>
</a>
<p>Somente usuários registrados têm acesso a esta página.</p>
      <a href="http://localhost:3000/Hbo">
      Hbo 
<p>

</p>
</a>
    </div>
  );
};

export default ContentPage;
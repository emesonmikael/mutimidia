
import React from "react";

const ProtectedPage = () => {
  return (
    <div>
      <h2>Página Protegida</h2>
      <p>Você só pode ver isso porque está conectado com sua carteira.</p>
      <a href="https://streamer-liard.vercel.app/netfli">
      Netflix Filme  
<p>

</p>
</a>
    </div>
  );
};

export default ProtectedPage;
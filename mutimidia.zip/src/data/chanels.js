const channels = [
    {
      name: "A FAZENDA PRINCIPAL",
      logo: "",
      url: "http://cdn-br.in:80/869290727/678528786/2586234.m3u8",
      group: "Canais || A Fazenda 16"
    },
    {
      name: "A FAZENDA 2",
      logo: "",
      url: "http://cdn-br.in:80/869290727/678528786/2586235.m3u8",
      group: "Canais || A Fazenda 16"
    },
    {
      name: "A FAZENDA 3",
      logo: "",
      url: "http://cdn-br.in:80/869290727/678528786/2586236.m3u8",
      group: "Canais || A Fazenda 16"
    },
    {
      name: "A FAZENDA 4",
      logo: "",
      url: "http://cdn-br.in:80/869290727/678528786/2586237.m3u8",
      group: "Canais || A Fazenda 16"
    },
    {
      name: "A FAZENDA 5",
      logo: "",
      url: "http://cdn-br.in:80/869290727/678528786/2586238.m3u8",
      group: "Canais || A Fazenda 16"
    },
    {
      name: "A FAZENDA 16 CAM 01",
      logo: "https://upload.wikimedia.org/wikipedia/pt/a/a3/A_Fazenda_16.png",
      url: "http://cdn-br.in:80/869290727/678528786/2586239.m3u8",
      group: "Canais || A Fazenda 16"
    },
    {
      name: "A FAZENDA 16 CAM 02",
      logo: "https://upload.wikimedia.org/wikipedia/pt/a/a3/A_Fazenda_16.png",
      url: "http://cdn-br.in:80/869290727/678528786/2586240.m3u8",
      group: "Canais || A Fazenda 16"
    },
    {
      name: "A FAZENDA 16 CAM 03",
      logo: "https://upload.wikimedia.org/wikipedia/pt/a/a3/A_Fazenda_16.png",
      url: "http://zlb177.office646851.online/auth/349.m3u8",
      group: "Canais || A Fazenda 16"
    }
  ];
  
  export default channels;